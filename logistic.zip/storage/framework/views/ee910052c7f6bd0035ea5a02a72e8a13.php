<div>
    <h1><?php echo e($count); ?></h1>
 
    <button wire:click="increment">+</button>
 
    <button wire:click="decrement">-</button>
</div><?php /**PATH F:\WebSpace\logistic\resources\views/livewire/counter.blade.php ENDPATH**/ ?>